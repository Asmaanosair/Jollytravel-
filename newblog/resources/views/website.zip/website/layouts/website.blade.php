
@include('website.layouts.includes.header')



@yield('content')


@include('website.layouts.includes.footer')