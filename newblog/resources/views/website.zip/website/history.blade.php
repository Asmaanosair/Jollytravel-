@extends('website.layouts.website')

@section('content')

    <div id="wrapper">
        <!-- content-->
        <div class="content">
            <!--  section  -->
            <section class="parallax-section single-par" data-scrollax-parent="true">
                <div class="bg par-elem "  data-bg="{{asset('website/assets/images/bg/1.jpg')}}" data-scrollax="properties: { translateY: '30%' }"></div>
                <div class="overlay"></div>
                <div class="container">
                    <div class="section-title center-align big-title">
                        <div class="section-title-separator"><span></span></div>
                        <h2><span>About Our Company</span></h2>
                        <span class="section-separator"></span>
                        <h4>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut nec tincidunt arcu, sit amet fermentum sem.</h4>
                    </div>
                </div>
                <div class="header-sec-link">
                    <div class="container"><a href="#sec1" class="custom-scroll-link color-bg"><i class="fal fa-angle-double-down"></i></a></div>
                </div>
            </section>
            <!--  section  end-->
            <div class="breadcrumbs-fs fl-wrap">
                <div class="container">
                    <div class="breadcrumbs fl-wrap"><a href="#">Home</a><a href="#">Pages</a><span>About Us</span></div>
                </div>
            </div>
            <section  id="sec1" class="middle-padding">
                <div class="container">
                    <!--about-wrap -->
                    <div class="about-wrap">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="video-box fl-wrap">
                                    <img src="{{asset('website/assets/images/all/1.jpg')}}" class="respimg" alt="">
                                    <a class="video-box-btn image-popup" href="https://vimeo.com/264074381"><i class="fa fa-play" aria-hidden="true"></i></a>
                                    <span class="video-box-title">Our Video Presentation</span>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="list-single-main-item-title fl-wrap">
                                    <h3>Vission <span>&</span> Mission</h3>
                                </div>
                                <p>Ut euismod ultricies sollicitudin. Curabitur sed dapibus nulla. Nulla eget iaculis lectus. Mauris ac maximus neque. Nam in mauris quis libero sodales eleifend. Morbi varius, nulla sit amet rutrum elementum, est elit finibus tellus, ut tristique elit risus at metus.</p>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar. Donec a consectetur nulla. Nulla posuere sapien vitae lectus suscipit, et pulvinar nisi tincidunt. Curabitur convallis fringilla diam sed aliquam. Sed tempor iaculis massa faucibus feugiat. In fermentum facilisis massa, a consequat purus viverra.  Aliquam erat volutpat. Curabitur convallis fringilla diam sed aliquam. Sed tempor iaculis massa faucibus feugiat. In fermentum facilisis massa, a consequat purus viverra.
                                </p>
                                <a href="#sec2" class="btn  color-bg float-btn custom-scroll-link">View Our Team <i class="fal fa-users"></i></a>
                            </div>
                        </div>
                    </div>


                </div>
            </section>
            <!-- section end -->
            <!--section -->
            <section class="color-bg hidden-section">
                <div class="wave-bg wave-bg2"></div>
                <div class="container">
                    <div class="section-title">
                        <h2>Why Choose Us</h2>
                        <span class="section-separator"></span>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar.</p>
                    </div>
                    <!-- -->
                    <div class="row">
                        <div class="col-md-4">
                            <!-- process-item-->
                            <div class="process-item big-pad-pr-item">
                                <span class="process-count"> </span>
                                <div class="time-line-icon"><i class="fal fa-headset"></i></div>
                                <h4><a href="#"> 24 Hours Support</a></h4>
                                <p>Proin dapibus nisl ornare diam varius tempus. Aenean a quam luctus, finibus tellus ut, convallis eros sollicitudin turpis.</p>
                            </div>
                            <!-- process-item end -->
                        </div>
                        <div class="col-md-4">
                            <!-- process-item-->
                            <div class="process-item big-pad-pr-item">
                                <span class="process-count"> </span>
                                <div class="time-line-icon"><i class="fal fa-cogs"></i></div>
                                <h4> <a href="#">Admin Panel</a></h4>
                                <p>Proin dapibus nisl ornare diam varius tempus. Aenean a quam luctus, finibus tellus ut, convallis eros sollicitudin turpis.</p>
                            </div>
                            <!-- process-item end -->
                        </div>
                        <div class="col-md-4">
                            <!-- process-item-->
                            <div class="process-item big-pad-pr-item nodecpre">
                                <span class="process-count"> </span>
                                <div class="time-line-icon"><i class="fab fa-android"></i></div>
                                <h4><a href="#"> Mobile Friendly</a></h4>
                                <p>Proin dapibus nisl ornare diam varius tempus. Aenean a quam luctus, finibus tellus ut, convallis eros sollicitudin turpis.</p>
                            </div>
                            <!-- process-item end -->
                        </div>
                    </div>
                    <!--process-wrap   end-->
                </div>
            </section>
            <!-- section end -->
            <!--section -->
            <section id="sec2">
                <div class="container">
                    <div class="section-title">
                        <h2>Our Team</h2>
                        <span class="section-separator"></span>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar.</p>
                    </div>
                    <div class="team-holder section-team fl-wrap">
                        <!-- team-item -->
                        <div class="team-box">
                            <div class="team-photo">
                                <img src="{{asset('website/assets/images/team/1.jpg')}}" alt="" class="respimg">
                            </div>
                            <div class="team-info">
                                <div class="team-dec"><i class="fal fa-chart-line"></i></div>
                                <h3><a href="#">Alisa Gray</a></h3>
                                <h4>Business consultant</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.  </p>
                                <div class="team-social">
                                    <ul>
                                        <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-vk"></i></a></li>
                                    </ul>
                                    <a class="team-contact_link" href="#"><i class="fal fa-envelope"></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- team-item  end-->
                        <!-- team-item -->
                        <div class="team-box">
                            <div class="team-photo">
                                <img src="{{asset('website/assets/images/team/1.jpg')}}" alt="" class="respimg">
                            </div>
                            <div class="team-info">
                                <div class="team-dec"><i class="fal fa-camera-retro"></i></div>
                                <h3><a href="#">Austin Evon</a></h3>
                                <h4>Photographer</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.  </p>
                                <div class="team-social">
                                    <ul>
                                        <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-vk"></i></a></li>
                                    </ul>
                                    <a class="team-contact_link" href="#"><i class="fal fa-envelope"></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- team-item end  -->
                        <!-- team-item -->
                        <div class="team-box">
                            <div class="team-photo">
                                <img src="{{asset('website/assets/images/team/1.jpg')}}" alt="" class="respimg">
                            </div>
                            <div class="team-info">
                                <div class="team-dec"><i class="fal fa-desktop"></i></div>
                                <h3><a href="#">Taylor Roberts</a></h3>
                                <h4>Co-manager associated</h4>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.  </p>
                                <div class="team-social">
                                    <ul>
                                        <li><a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-twitter"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-instagram"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fab fa-vk"></i></a></li>
                                    </ul>
                                    <a class="team-contact_link" href="#"><i class="fal fa-envelope"></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- team-item end  -->
                    </div>
                </div>
            </section>
            <!-- section end -->
            <section class="parallax-section" data-scrollax-parent="true">
                <div class="bg par-elem "  data-bg="{{asset('website/assets/images/bg/1.jpg')}}" data-scrollax="properties: { translateY: '30%' }"></div>
                <div class="overlay"></div>
                <!--container-->
                <div class="container">
                    <div class="intro-item fl-wrap">
                        <h2>Need more information</h2>
                        <h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore.</h3>
                        <a class="btn  color-bg" href="contacts.html">Get in Touch <i class="fal fa-envelope"></i></a>
                    </div>
                </div>
            </section>
            <section>
                <div class="container">
                    <div class="section-title">
                        <h2>Testimonials</h2>
                        <span class="section-separator"></span>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar.</p>
                    </div>
                </div>
                <div class="clearfix"></div>
                <!--slider-carousel-wrap -->
                <div class="slider-carousel-wrap text-carousel-wrap fl-wrap">
                    <div class="swiper-button-prev sw-btn"><i class="fa fa-long-arrow-left"></i></div>
                    <div class="swiper-button-next sw-btn"><i class="fa fa-long-arrow-right"></i></div>
                    <div class="text-carousel single-carousel cur_carousel-slider-container fl-wrap">
                        <!--slick-item -->
                        <div class="slick-item">
                            <div class="text-carousel-item">
                                <div class="popup-avatar"><img src="{{asset('website/assets/images/avatar/1.jpg')}}" alt=""></div>
                                <div class="listing-rating card-popup-rainingvis" data-starrating2="5"> </div>
                                <div class="review-owner fl-wrap">Milka Antony  - <span>Happy Client</span></div>
                                <p> "In ut odio libero, at vulputate urna. Nulla tristique mi a massa convallis cursus. Nulla eu mi magna. Etiam suscipit commodo gravida. Lorem ipsum dolor sit amet, conse ctetuer adipiscing elit, sed diam nonu mmy nibh euismod tincidunt ut laoreet dolore magna aliquam erat."</p>
                                <a href="#" class="testim-link">Via Facebook</a>
                            </div>
                        </div>
                        <!--slick-item end -->
                        <!--slick-item -->
                        <div class="slick-item">
                            <div class="text-carousel-item">
                                <div class="popup-avatar"><img src="{{asset('website/assets/images/avatar/1.jpg')}}" alt=""></div>
                                <div class="listing-rating card-popup-rainingvis" data-starrating2="4"> </div>
                                <div class="review-owner fl-wrap">Milka Antony  - <span>Happy Client</span></div>
                                <p> "In ut odio libero, at vulputate urna. Nulla tristique mi a massa convallis cursus. Nulla eu mi magna. Etiam suscipit commodo gravida. Lorem ipsum dolor sit amet, conse ctetuer adipiscing elit, sed diam nonu mmy nibh euismod tincidunt ut laoreet dolore magna aliquam erat."</p>
                                <a href="#" class="testim-link">Via Facebook</a>
                            </div>
                        </div>
                        <!--slick-item end -->
                        <!--slick-item -->
                        <div class="slick-item">
                            <div class="text-carousel-item">
                                <div class="popup-avatar"><img src="{{asset('website/assets/images/avatar/1.jpg')}}" alt=""></div>
                                <div class="listing-rating card-popup-rainingvis" data-starrating2="5"> </div>
                                <div class="review-owner fl-wrap">Milka Antony  - <span>Happy Client</span></div>
                                <p> "In ut odio libero, at vulputate urna. Nulla tristique mi a massa convallis cursus. Nulla eu mi magna. Etiam suscipit commodo gravida. Lorem ipsum dolor sit amet, conse ctetuer adipiscing elit, sed diam nonu mmy nibh euismod tincidunt ut laoreet dolore magna aliquam erat."</p>
                                <a href="#" class="testim-link">Via Facebook</a>
                            </div>
                        </div>
                        <!--slick-item end -->
                        <!--slick-item -->
                        <div class="slick-item">
                            <div class="text-carousel-item">
                                <div class="popup-avatar"><img src="{{asset('website/assets/images/avatar/1.jpg')}}" alt=""></div>
                                <div class="listing-rating card-popup-rainingvis" data-starrating2="5"> </div>
                                <div class="review-owner fl-wrap">Milka Antony  - <span>Happy Client</span></div>
                                <p> "In ut odio libero, at vulputate urna. Nulla tristique mi a massa convallis cursus. Nulla eu mi magna. Etiam suscipit commodo gravida. Lorem ipsum dolor sit amet, conse ctetuer adipiscing elit, sed diam nonu mmy nibh euismod tincidunt ut laoreet dolore magna aliquam erat."</p>
                                <a href="#" class="testim-link">Via Facebook</a>
                            </div>
                        </div>
                        <!--slick-item end -->
                    </div>
                </div>
                <!--slider-carousel-wrap end-->
                <div class="section-decor"></div>
            </section>
        </div>
        <!-- content end-->
    </div>



@stop
